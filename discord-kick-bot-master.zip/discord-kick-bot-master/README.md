# discord-kick-bot
A discord bot that listens to the kick command to remove users from the guild.

1. Install node.js.

2. Create a new folder for your bot and initialize it with npm by typing npm init at the command line interface.

3. Install slappey by typing npm i slappey -g at the command line interface. 

4. Run slappey and select New
  Go through the various prompts for prefix and token.

5. Now create a new command by typing slappey and selecting Generate->Command, give the command a name kick.

6. Copy and paste the KickCommand.js from the project directory.

7. Add the bot to a server via the discord developers console.

8. Type npm start at the command line interface, now your bot is up and running and must show online on the server.

9. Test the bot out in the server chat by typing in your-bot-prefixkick @mention-username-here [reason].
